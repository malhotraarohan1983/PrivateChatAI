package com.privatechatai.network

import com.privatechatai.data.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.client.plugins.sse.*
import io.ktor.client.request.forms.*
import io.ktor.http.*
import kotlinx.serialization.json.*
import java.io.File

class PrivateChatApi(private val client:HttpClient, private val baseUrl:String, private val token:String?) {
 private fun HttpRequestBuilder.auth(){ token?.takeIf{it.isNotBlank()}?.let{header("X-Client-Token",it)} }
 suspend fun models():List<ModelInfo> = client.get("${baseUrl.trimEnd('/')}/models"){auth()}.body()
 suspend fun generateImage(prompt:String,model:String):ImageResult = client.post("${baseUrl.trimEnd('/')}/image/generate"){auth();contentType(ContentType.Application.Json);setBody(mapOf("prompt" to prompt,"model" to model))}.body()
 suspend fun editImage(file:File,prompt:String,model:String):ImageResult = client.submitFormWithBinaryData("${baseUrl.trimEnd('/')}/image/edit",formData=formData{append("prompt",prompt);append("model",model);append("image",file.readBytes(),Headers.build{append(HttpHeaders.ContentType,"image/jpeg");append(HttpHeaders.ContentDisposition,"filename=upload.jpg")})}){auth()}.body()
 suspend fun streamChat(request:ChatRequest,onDelta:(String)->Unit){client.sse("${baseUrl.trimEnd('/')}/chat",request={auth();method=HttpMethod.Post;contentType(ContentType.Application.Json);setBody(request)}){incoming.collect{ev->if(ev.data=="[DONE]")return@collect;ev.data?.let{data->runCatching{Json.parseToJsonElement(data).jsonObject}.getOrNull()?.let{obj->obj["delta"]?.jsonPrimitive?.content?.let(onDelta);obj["error"]?.jsonPrimitive?.content?.let{throw IllegalStateException(it)}}}}}}
}
