# Keep Kotlin serialization metadata and Room generated code.
-keep class kotlinx.serialization.** { *; }
-keep class com.privatechatai.data.** { *; }
