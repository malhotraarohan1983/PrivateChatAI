package com.privatechatai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.privatechatai.data.*
import com.privatechatai.network.PrivateChatApi
import io.ktor.client.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import android.content.ClipData
import android.content.ClipboardManager
import java.util.UUID

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{PrivateChatApp()}}}

class ChatViewModel(private val db:ChatDatabase, private val settings:SettingsStore):ViewModel(){
 private val dao=db.dao(); val conversations=dao.conversations().stateIn(kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO),SharingStarted.Eagerly,emptyList())
 var currentId by mutableStateOf<String?>(null); var draft by mutableStateOf(""); var selectedImage by mutableStateOf<Uri?>(null); var sending by mutableStateOf(false); var error by mutableStateOf<String?>(null); var model by mutableStateOf("gpt-5.6-luna"); var systemPrompt by mutableStateOf(""); private var generationJob:kotlinx.coroutines.Job?=null; private val scope=kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob()+kotlinx.coroutines.Dispatchers.IO)
 private fun api():PrivateChatApi{val url=runBlockingNoSuspend{settings.read()["url"]?:com.privatechatai.BuildConfig.DEFAULT_BACKEND_URL};val tok=runBlockingNoSuspend{settings.read()["token"]};return PrivateChatApi(HttpClient(OkHttp){install(ContentNegotiation){json()}},url,tok)}
 fun select(id:String){currentId=id}
 fun newChat(){val id=UUID.randomUUID().toString();currentId=id;kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch{dao.upsertConversation(ConversationEntity(id,"New chat",System.currentTimeMillis(),System.currentTimeMillis()))}}
 fun send(){val cid=currentId?:run{newChat();currentId!!};val text=draft.trim();if(text.isEmpty()||sending)return;draft="";sending=true;val user=MessageEntity(UUID.randomUUID().toString(),cid,"user",text,null,System.currentTimeMillis());kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch{
  dao.insertMessage(user);dao.upsertConversation(ConversationEntity(cid,text.take(40),user.createdAt,user.createdAt));val history=dao.messages(cid).first().map{ApiMessage(it.role,it.text)};val aiId=UUID.randomUUID().toString();dao.insertMessage(MessageEntity(aiId,cid,"assistant","",null,System.currentTimeMillis()));
  generationJob=scope.launch{try{api().streamChat(ChatRequest(model,history,systemPrompt.ifBlank{null})){delta->val msgs=dao.messages(cid).first();val m=msgs.firstOrNull{it.id==aiId}?:return@streamChat;dao.insertMessage(m.copy(text=m.text+delta))};sending=false}catch(e:Throwable){error=e.message;sending=false}}
 }}
 fun stop(){generationJob?.cancel();generationJob=null;sending=false}
 fun rename(id:String,title:String){kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch{val c=conversations.value.firstOrNull{it.id==id};if(c!=null)dao.upsertConversation(c.copy(title=title,updatedAt=System.currentTimeMillis()))}}
 fun delete(id:String){kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch{dao.deleteMessages(id);dao.deleteConversation(id);if(currentId==id)currentId=null}}
 fun messages(id:String):Flow<List<MessageEntity>> = dao.messages(id)
}
private fun <T> runBlockingNoSuspend(block:suspend()->T):T=kotlinx.coroutines.runBlocking{block()}

@Composable fun PrivateChatApp(){
 val ctx=androidx.compose.ui.platform.LocalContext.current
 val factory=remember(ctx){object:androidx.lifecycle.ViewModelProvider.Factory{override fun <T:ViewModel> create(c:Class<T>):T{
   @Suppress("UNCHECKED_CAST") return ChatViewModel(ChatDatabase.get(ctx),SettingsStore(ctx)) as T
 }}}
 val vm:ChatViewModel=viewModel(factory=factory)
 AppScreen(vm)
}

@Composable fun AppScreen(vm:ChatViewModel){
 MaterialTheme(colorScheme=lightColorScheme()){
  var drawer by remember{mutableStateOf(true)}
  Row(Modifier.fillMaxSize()){
   if(drawer) HistoryPane(vm,Modifier.width(280.dp))
   Column(Modifier.fillMaxSize()){
    TopAppBar(title={Text("PrivateChat AI")},navigationIcon={IconButton({drawer=!drawer}){Icon(Icons.Default.Menu,"Menu")}},actions={IconButton({}){Icon(Icons.Default.Settings,"Settings")}})
    val cid=vm.currentId
    if(cid==null) Welcome(vm) else ChatPane(vm,cid)
   }
  }
 }
}
@Composable fun HistoryPane(vm:ChatViewModel,modifier:Modifier){Column(modifier.fillMaxHeight().padding(12.dp)){Button({vm.newChat()},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("New Chat")};Spacer(Modifier.height(12.dp));Text("Conversations",style=MaterialTheme.typography.labelLarge);LazyColumn{items(vm.conversations.value,key={it.id}){c->Row(Modifier.fillMaxWidth().clickable{vm.select(c.id)}.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Text(c.title,Modifier.weight(1f),maxLines=1);IconButton({vm.delete(c.id)}){Icon(Icons.Default.Delete,null)}}}}}}
@Composable fun Welcome(vm:ChatViewModel){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("PrivateChat AI",style=MaterialTheme.typography.headlineLarge);Text("Private, self-hosted AI chat",Modifier.padding(8.dp));Button({vm.newChat()}){Text("Start a new chat")}}}}
@Composable fun ChatPane(vm:ChatViewModel,id:String){val msgs by vm.messages(id).collectAsState(initial=emptyList());var input by remember{mutableStateOf("")};val launcher=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){vm.selectedImage=it};Column(Modifier.fillMaxSize()){
 LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal=12.dp),contentPadding=PaddingValues(vertical=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(msgs,key={it.id}){m->MessageBubble(m)}}
 if(vm.error!=null)Text(vm.error!!,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(12.dp))
 Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.Bottom){IconButton({launcher.launch("image/*")}){Icon(Icons.Default.AttachFile,"Attach image")};OutlinedTextField(value=input,onValueChange={input=it;vm.draft=it},modifier=Modifier.weight(1f),placeholder={Text("Message PrivateChat AI…")},maxLines=6);Spacer(Modifier.width(6.dp));IconButton({vm.send();input=""},enabled=!vm.sending&&input.isNotBlank()){Icon(Icons.Default.Send,"Send")}}
}}
@Composable fun MessageBubble(m:MessageEntity){val user=m.role=="user";Row(Modifier.fillMaxWidth(),horizontalArrangement=if(user)Arrangement.End else Arrangement.Start){Surface(shape=RoundedCornerShape(18.dp),color=if(user)MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,modifier=Modifier.widthIn(max=760.dp)){Column(Modifier.padding(12.dp)){Text(if(user)"You" else "AI",style=MaterialTheme.typography.labelMedium);Spacer(Modifier.height(4.dp));Text(m.text,fontFamily=if(m.text.trim().startsWith("```"))FontFamily.Monospace else FontFamily.Default);if(!user&&m.text.isNotBlank())TextButton({}){Text("Copy")}}}}}
