package com.privatechatai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first

private val Context.store by preferencesDataStore("settings")
class SettingsStore(private val context:Context){
 private val url=stringPreferencesKey("backend_url"); private val token=stringPreferencesKey("client_token"); private val model=stringPreferencesKey("model"); private val prompt=stringPreferencesKey("system_prompt"); private val dark=booleanPreferencesKey("dark")
 suspend fun read():Map<String,String?>{val p=context.store.data.first();return mapOf("url" to p[url],"token" to p[token],"model" to p[model],"prompt" to p[prompt],"dark" to p[dark]?.toString())}
 suspend fun set(k:String,v:String){context.store.edit{p->when(k){"url"->p[url]=v;"token"->p[token]=v;"model"->p[model]=v;"prompt"->p[prompt]=v;"dark"->p[dark]=v.toBoolean()}}}
}
