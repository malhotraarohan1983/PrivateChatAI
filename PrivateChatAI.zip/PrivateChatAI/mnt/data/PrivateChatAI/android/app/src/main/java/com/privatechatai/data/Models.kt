package com.privatechatai.data

import kotlinx.serialization.Serializable

@Serializable data class ApiMessage(val role: String, val content: String, val imageUrl: String? = null)
@Serializable data class ChatRequest(val model: String, val messages: List<ApiMessage>, val systemPrompt: String? = null)
@Serializable data class ModelInfo(val id: String, val name: String, val provider: String)
@Serializable data class ImageResult(val id: String, val imageDataUrl: String, val prompt: String)

enum class Role { USER, ASSISTANT }

data class ChatMessage(val id: String, val conversationId: String, val role: Role, val text: String, val imageUri: String? = null, val createdAt: Long = System.currentTimeMillis())
data class Conversation(val id: String, val title: String, val createdAt: Long, val updatedAt: Long)
