package com.privatechatai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="conversations") data class ConversationEntity(@PrimaryKey val id:String,val title:String,val createdAt:Long,val updatedAt:Long)
@Entity(tableName="messages", indices=[Index("conversationId")]) data class MessageEntity(@PrimaryKey val id:String,val conversationId:String,val role:String,val text:String,val imageUri:String?,val createdAt:Long)

@Dao interface ChatDao {
 @Query("SELECT * FROM conversations ORDER BY updatedAt DESC") fun conversations(): Flow<List<ConversationEntity>>
 @Query("SELECT * FROM messages WHERE conversationId=:id ORDER BY createdAt ASC") fun messages(id:String): Flow<List<MessageEntity>>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertConversation(c:ConversationEntity)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertMessage(m:MessageEntity)
 @Query("DELETE FROM messages WHERE conversationId=:id") suspend fun deleteMessages(id:String)
 @Query("DELETE FROM conversations WHERE id=:id") suspend fun deleteConversation(id:String)
}

@Database(entities=[ConversationEntity::class,MessageEntity::class],version=1,exportSchema=false)
abstract class ChatDatabase:RoomDatabase(){ abstract fun dao():ChatDao
 companion object { @Volatile private var INSTANCE:ChatDatabase?=null
  fun get(context:Context)=INSTANCE?: synchronized(this){ INSTANCE?:Room.databaseBuilder(context,ChatDatabase::class.java,"privatechat.db").build().also{INSTANCE=it} }
 }
}
