import fs from 'node:fs';
import OpenAI from 'openai';
import {config} from '../config.js';
const client=new OpenAI({apiKey:config.openaiKey,baseURL:config.openaiBaseUrl});
function assertKey(){if(!config.openaiKey)throw new Error('OPENAI_API_KEY is not configured on the server');}
export async function streamChat({model,messages,systemPrompt,onDelta}){assertKey();const input=messages.map(m=>({role:m.role,content:m.content}));const stream=await client.responses.create({model:model||config.chatModel,instructions:systemPrompt||undefined,input,stream:true});let full='';for await(const event of stream){if(event.type==='response.output_text.delta'){full+=event.delta;onDelta(event.delta)}}return full}
export async function generateImage({prompt,model}){assertKey();const result=await client.images.generate({model:model||config.imageModel,prompt,size:'1024x1024',quality:'auto'});const b64=result.data?.[0]?.b64_json;if(!b64)throw new Error('Provider returned no image');return `data:image/png;base64,${b64}`}
export async function editImage({prompt,model,imagePath}){assertKey();const result=await client.images.edit({model:model||config.imageModel,image:fs.createReadStream(imagePath),prompt,size:'1024x1024'});const b64=result.data?.[0]?.b64_json;if(!b64)throw new Error('Provider returned no image');return `data:image/png;base64,${b64}`}
