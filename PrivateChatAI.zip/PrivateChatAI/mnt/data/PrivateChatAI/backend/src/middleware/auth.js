import {config} from '../config.js';
export function auth(req,res,next){if(!config.clientToken)return next();if(req.get('X-Client-Token')!==config.clientToken)return res.status(401).json({error:'Unauthorized'});next()}
