import 'dotenv/config';
export const config={
 port:Number(process.env.PORT||8080),host:process.env.HOST||'0.0.0.0',clientToken:process.env.CLIENT_TOKEN||'',dbPath:process.env.DATABASE_PATH||'./data/privatechat.sqlite',
 openaiKey:process.env.OPENAI_API_KEY||'',openaiBaseUrl:process.env.OPENAI_BASE_URL||'https://api.openai.com/v1',chatModel:process.env.CHAT_MODEL||'gpt-5.6-luna',imageModel:process.env.IMAGE_MODEL||'gpt-image-2',maxBodyMb:Number(process.env.MAX_BODY_MB||12),corsOrigin:process.env.CORS_ORIGIN||'*'
};
