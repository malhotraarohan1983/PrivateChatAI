import {Router} from 'express'; import {listConversations,getMessages,removeConversation} from '../db/database.js';
const router=Router();
router.get('/',(req,res)=>res.json(listConversations()));
router.get('/:id/messages',(req,res)=>res.json(getMessages(req.params.id)));
router.delete('/:id',(req,res)=>{removeConversation(req.params.id);res.status(204).end()});
export default router;
