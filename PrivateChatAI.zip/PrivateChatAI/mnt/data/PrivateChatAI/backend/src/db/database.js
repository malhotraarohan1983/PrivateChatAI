import fs from 'node:fs'; import path from 'node:path'; import Database from 'better-sqlite3'; import {config} from '../config.js';
fs.mkdirSync(path.dirname(path.resolve(config.dbPath)),{recursive:true});
export const db=new Database(config.dbPath); db.pragma('journal_mode = WAL'); db.exec(`CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,title TEXT NOT NULL,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL); CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,conversation_id TEXT NOT NULL,role TEXT NOT NULL,content TEXT NOT NULL,created_at INTEGER NOT NULL,FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE);`);
export function upsertConversation(c){db.prepare('INSERT INTO conversations(id,title,created_at,updated_at) VALUES(@id,@title,@created_at,@updated_at) ON CONFLICT(id) DO UPDATE SET title=excluded.title,updated_at=excluded.updated_at').run(c)}
export function listConversations(){return db.prepare('SELECT id,title,created_at as createdAt,updated_at as updatedAt FROM conversations ORDER BY updated_at DESC').all()}
export function getMessages(id){return db.prepare('SELECT id,role,content,created_at as createdAt FROM messages WHERE conversation_id=? ORDER BY created_at ASC').all(id)}
export function addMessage(m){db.prepare('INSERT INTO messages(id,conversation_id,role,content,created_at) VALUES(@id,@conversation_id,@role,@content,@created_at)').run(m)}
export function removeConversation(id){db.prepare('DELETE FROM messages WHERE conversation_id=?').run(id);db.prepare('DELETE FROM conversations WHERE id=?').run(id)}
