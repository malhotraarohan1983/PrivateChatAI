# PrivateChat AI

PrivateChat AI is a native Kotlin/Jetpack Compose Android chat client backed by a self-hostable Node.js/Express API. Provider credentials stay on the backend; the APK never contains an AI-provider API key.

## Architecture

```text
Android app (Compose)
  ├─ local Room conversation cache
  ├─ encrypted settings / optional backend token
  ├─ image picker + preview
  └─ HTTPS REST + SSE
             │
             ▼
Self-hosted Node/Express backend
  ├─ auth middleware
  ├─ SQLite persistence
  ├─ /chat (SSE streaming)
  ├─ /image/generate
  ├─ /image/edit (multipart)
  ├─ /models
  └─ /conversations
             │
             ▼
Provider adapter (OpenAI today; replaceable later)
```

OpenAI's current API supports streaming Responses events and server-side API-key authentication; keys should be kept server-side, not embedded in mobile applications. urlOpenAI API authentication and quickstarthttps://platform.openai.com/docs/quickstart/make-your-first-api-request

## Backend setup

Requirements: Node.js 20+, npm, a provider API key, and a TLS reverse proxy for production.

```bash
cd backend
cp .env.example .env
# edit .env and set OPENAI_API_KEY and a strong CLIENT_TOKEN
npm install
npm start
```

For local Android emulator development, the default backend URL is `http://10.0.2.2:8080/`. For a physical phone use your LAN HTTPS endpoint, for example `https://chat.example.com/`.

### Production HTTPS

Do not expose the Node process directly to the Internet. Put Caddy, Nginx, Traefik, or a managed HTTPS load balancer in front of it. Restrict inbound traffic, use a strong `CLIENT_TOKEN`, and keep `.env` outside source control.

Example Caddy configuration:

```text
chat.example.com {
    reverse_proxy 127.0.0.1:8080
}
```

## API

### POST /chat

Request:

```json
{
  "conversationId":"uuid",
  "model":"gpt-5.6-luna",
  "systemPrompt":"You are concise.",
  "messages":[
    {"role":"user","content":"Hello"}
  ]
}
```

Response is Server-Sent Events. Delta events are JSON objects such as `{"delta":"Hello"}` followed by `data: [DONE]`.

### POST /image/generate

JSON body: `{ "prompt": "...", "model": "gpt-image-2" }`.

### POST /image/edit

Multipart fields: `image`, `prompt`, optional `model`. The backend deletes the temporary upload after the provider call.

### GET /models
Returns the configured model list. Add more provider adapters and expose their models here.

### GET /conversations
Returns server-side conversation metadata. `GET /conversations/:id/messages` returns stored messages. `DELETE /conversations/:id` removes them.

## Privacy model

- No provider API key is shipped in the Android project.
- Backend request logging is disabled by default; application errors contain no message bodies.
- Uploaded edit files are stored temporarily and deleted after processing.
- The server persists conversation text only because persistent server history was requested; this can be disabled by removing the DB writes in `routes/chat.js`.
- The Android client maintains a separate local Room cache. A production hardening pass should use encrypted database fields or SQLCipher before storing sensitive text on-device.
- No analytics, ads, or tracking SDKs are included.

## Android build

Install Android Studio with JDK 17 and Android SDK 35. From the repository root:

```bash
./gradlew :android:app:assembleDebug
./gradlew :android:app:bundleRelease
```

The release build is configured for R8/minification. Before distributing a signed AAB/APK, create a release signing configuration in `android/app/build.gradle.kts` (prefer Gradle properties or a CI secret, never commit the keystore/password).

## Extending providers

The backend intentionally keeps provider-specific code in `src/services/provider.js`. For Anthropic, Gemini, local Ollama, vLLM, or another OpenAI-compatible gateway, add a provider module implementing:

- `streamChat()`
- `generateImage()`
- `editImage()`

Then select it from environment configuration. The Android API remains unchanged.

## Important production hardening

Before exposing this to untrusted users, add real user authentication/authorization, per-user conversation ownership, rate limiting, request quotas, audit/security monitoring without content logging, CSRF protections where applicable, strict CORS, encrypted server storage, secret management (Vault/KMS), database backups, and a formal privacy/retention policy. A shared client token is suitable for a private/self-hosted deployment, not a public multi-user service.
